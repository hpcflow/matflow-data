%CONTENTS MATGEOM Geometric Computing Toolbox.
% Version 1.0 26-07-2017.
