%CONTENTS POLYGONS Manipulation of planar polygons and polylines.
% Version 1.24 07-Jun-2018 .
